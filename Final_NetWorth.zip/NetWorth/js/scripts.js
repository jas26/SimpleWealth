/*!
* Start Bootstrap - Freelancer v7.0.6 (https://startbootstrap.com/theme/freelancer)
* Copyright 2013-2022 Start Bootstrap
* Licensed under MIT (https://github.com/StartBootstrap/startbootstrap-freelancer/blob/master/LICENSE)
*/
//
// Scripts
// 



    window.addEventListener('DOMContentLoaded', event => {
        function cal_NetWorth(){
            var cash = document.getElementById("cash").value;
            var savings = document.getElementById("savings").value;
            var investment = document.getElementById("investment").value;
            var retirement_estate = document.getElementById("retirement_estate").value;
            var crypto_amount = document.getElementById("crypto_amount").value;
            var real_estate = document.getElementById("real_estate").value;
            var home_equity = document.getElementById("home_equity").value;
            var crypto_amount = document.getElementById("auto").value;
            var asset_total = cash+savings+investment+retirement_estate+crypto_amount+real_estate+home_equity+crypto_amount
            document.getElementById("assets_total").innerHTML = asset_total;
            var student_loan_debt = document.getElementById("student_loan_debt").value;
            var credit_loan_debt = document.getElementById("credit_loan_debt").value;
            var personal_loans = document.getElementById("personal_loans").value;
            var home_mortgage = document.getElementById("home_mortgage").value;
            var car_loans = document.getElementById("car_loans").value;
            var l_total = student_loan_debt+credit_loan_debt+personal_loans+home_mortgage+car_loans
            document.getElementById("assets_total").innerHTML = l_total;
            var asset_total = cash+savings+investment+retirement_estate+crypto_amount+real_estate+home_equity+crypto_amount
            document.getElementById("assets_total").innerHTML = asset_total;
            var l_total = student_loan_debt+credit_loan_debt+personal_loans+home_mortgage+car_loans
            document.getElementById("liabilities_total").innerHTML = l_total;
        }
    // Navbar shrink function
    var navbarShrink = function () {
        const navbarCollapsible = document.body.querySelector('#mainNav');
        if (!navbarCollapsible) {
            return;
        }
        if (window.scrollY === 0) {
            navbarCollapsible.classList.remove('navbar-shrink')
        } else {
            navbarCollapsible.classList.add('navbar-shrink')
        }

    };

    // Shrink the navbar 
    //navbarShrink();
//
    //// Shrink the navbar when page is scrolled
    //document.addEventListener('scroll', navbarShrink);

    // Activate Bootstrap scrollspy on the main nav element
    const mainNav = document.body.querySelector('#mainNav');
    if (mainNav) {
        new bootstrap.ScrollSpy(document.body, {
            target: '#mainNav',
            offset: 72,
        });
    };

    // Collapse responsive navbar when toggler is visible
    const navbarToggler = document.body.querySelector('.navbar-toggler');
    const responsiveNavItems = [].slice.call(
        document.querySelectorAll('#navbarResponsive .nav-link')
    );
    responsiveNavItems.map(function (responsiveNavItem) {
        responsiveNavItem.addEventListener('click', () => {
            if (window.getComputedStyle(navbarToggler).display !== 'none') {
                navbarToggler.click();
            }
        });
    });

});
